package exam_student;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;

import report.Student;

public class DatabaseController {

	public static boolean deleteQueryID(String id) throws Exception {
		boolean flag = true;
		
		Connection connection = DBUtil.getConnection();
		String deleteQuery = "delete from scoretbl where id = ?";
		
		PreparedStatement preparedStatement = null;
		
		try {
			preparedStatement = connection.prepareStatement(deleteQuery);
			preparedStatement.setString(1, id);
			
			int count = preparedStatement.executeUpdate();
			
			if(count == 1) {
				System.out.println("���� ����");
				flag = true;
			}else {
				System.out.println("���� ����");
			}
		}catch (Exception e) {
			System.out.println("����Ÿ���̽� �κп��� ������ �߻��߽��ϴ�. ���˹ٶ�");
		}finally {
			if(preparedStatement != null) {
				preparedStatement.close();
			}
			if(connection != null) {
				connection.close();
			}
		}
		
		return flag;
	}

	public static HashSet<ScoreTable> selectScoreTBLTotal() throws Exception {
		HashSet<ScoreTable> hashSet = new HashSet<ScoreTable>();
		
		Connection connection = DBUtil.getConnection();
		
		PreparedStatement preparedStatement = null;
		String selectQuery = "select * from scoretbl";
		
		try {
			preparedStatement = connection.prepareStatement(selectQuery);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			
			while(resultSet.next()) {
				int no = resultSet.getInt(1);
				String id = resultSet.getString(2);
				String studentName = resultSet.getString(3);
				int c = resultSet.getInt(4);
				int java = resultSet.getInt(5);
				int dataB = resultSet.getInt(6);
				int android = resultSet.getInt(7);
				int total = resultSet.getInt(8);
				double avg = resultSet.getDouble(9);
				String grade = resultSet.getString(10);
				
				ScoreTable scoreTable = new ScoreTable(no, id, studentName, c, java, dataB, android, total, avg, grade);
				hashSet.add(scoreTable);
			}
			
		}catch (Exception e) {
			System.out.println("select query erro"+ e.toString());
		}finally {
			if(preparedStatement != null) {
				preparedStatement.close();
			}
			if(connection != null) {
				connection.close();
			}
		}
		return hashSet;
	}

	public static boolean insertMemberTBL(ScoreTable inputScoreTable) throws Exception {
		boolean flag =false;
		Connection connection = DBUtil.getConnection();
		String insertQuery = "call cal_procedure(?,?,?,?,?,?)";
		PreparedStatement preparedStatement =null;
		try {
			preparedStatement =connection.prepareStatement(insertQuery);
			preparedStatement.setString(1, inputScoreTable.getId());
			preparedStatement.setString(2, inputScoreTable.getStudentName());
			preparedStatement.setInt(3, inputScoreTable.getJava());
			preparedStatement.setInt(4, inputScoreTable.getDataB());
			preparedStatement.setInt(5, inputScoreTable.getAndroid());
			preparedStatement.setInt(6, inputScoreTable.getC());
			int count = preparedStatement.executeUpdate();
			if(count ==1) {
				System.out.println("Insert Success.");
				flag =true;
			}
		}catch(Exception e) {
			System.out.println("Error Insert.");
		}finally {
			if(preparedStatement !=null) {
				preparedStatement.close();
			}
			if(connection !=null) {
				connection.close();
			}
		}
		return flag;
	}

	public static ScoreTable selectQueryWhereID(String id) throws Exception {
		ScoreTable scoreTable =null;
		Connection connection = DBUtil.getConnection();
		String selectQuery = "select * from scoretbl where id = ?";
		PreparedStatement preparedStatement =null;
		try {
			preparedStatement =connection.prepareStatement(selectQuery);
			preparedStatement.setString(1, id);
			ResultSet set = preparedStatement.executeQuery();
			while(set.next()){
				int no = set.getInt(1);
				String id_db = set.getString(2);
				String studentName = set.getString(3);
				int java = set.getInt(4);
				int dataB =set.getInt(5);
				int android =set.getInt(6);
				int c =set.getInt(7);
				int total =set.getInt(8);
				double avg =set.getDouble(9);
				String grade =set.getString(10);
				
				scoreTable = new ScoreTable(no, id, studentName, java, dataB, android, c, total, avg, grade);
			}
		}catch(Exception e) {
			System.out.println("Error Select.");
		}finally {
			if(preparedStatement !=null) {
				preparedStatement.close();
			}
			if(connection !=null) {
				connection.close();
			}
		}
		return scoreTable;
	}

	public static boolean insertScoreTable(ScoreTable inputScoreTable) throws Exception {
		boolean flag = false;
		Connection connection = DBUtil.getConnection();
		String insertQuery = "call pro_calculate_insert(?, ?, ?, ?, ?, ?);";
		
		PreparedStatement preparedStatement = null;
		
		try {
			preparedStatement = connection.prepareStatement(insertQuery);
			preparedStatement.setString(1, inputScoreTable.getId());
			preparedStatement.setString(2, inputScoreTable.getStudentName());
			preparedStatement.setInt(3, inputScoreTable.getJava());
			preparedStatement.setInt(4, inputScoreTable.getDataB());
			preparedStatement.setInt(5, inputScoreTable.getAndroid());
			preparedStatement.setInt(6, inputScoreTable.getC());
			int count = preparedStatement.executeUpdate();
			
			if(count == 1) {
				System.out.println("���Կ� �����ϼ̽��ϴ�.");
				flag = true;
			}
		}catch (Exception e) {
			System.out.println("���� ����");
		}finally {
			if(preparedStatement  != null) {
				preparedStatement.close();
			}
			if(connection != null) {
				connection.close();
			}
		}
		return flag;
	}

	public static ScoreTable selectQueryScoreTable(String inputId) throws Exception {
		ScoreTable scoreTable = null;
		Connection connection = DBUtil.getConnection();
		String selectQuery = "select * from scoretbl where id = ?";
		PreparedStatement preparedStatement = null;
		
		try {
			preparedStatement = connection.prepareStatement(selectQuery);
			preparedStatement.setString(1, inputId);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				int no = resultSet.getInt(1);
				String id = resultSet.getString(2);
				String name = resultSet.getString(3);
				int java = resultSet.getInt(4);
				int dataB = resultSet.getInt(5);
				int android = resultSet.getInt(6);
				int c = resultSet.getInt(7);
				int total = resultSet.getInt(8);
				double avg = resultSet.getDouble(9);
				String grade = resultSet.getString(10);
				scoreTable = new ScoreTable(no, id, name, java, dataB, android, c, total, avg, grade);
			}
		}catch (Exception e) {
			System.out.println("DB���� ������ �ҷ����� �� ������ �߻��߽��ϴ�.");
		}
		return scoreTable;
	}

	public static boolean updateQueryScoreTable(ScoreTable inputScoreTable) throws Exception {
		boolean flag = false;
		Connection connection = DBUtil.getConnection();
		String updateQuery = "call pro_calculate_update(?, ?, ?, ?, ?)";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(updateQuery);
			preparedStatement.setString(1, inputScoreTable.getId());
			preparedStatement.setInt(2, inputScoreTable.getJava());
			preparedStatement.setInt(3, inputScoreTable.getDataB());
			preparedStatement.setInt(4, inputScoreTable.getAndroid());
			preparedStatement.setInt(5, inputScoreTable.getC());
			int count = preparedStatement.executeUpdate();
			if(count == 1) {
				System.out.println("�������� ������Ʈ ����");
				flag = true;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
			System.out.println("DB���� ������Ʈ ���� �߻�");
		}finally {
			if(preparedStatement != null) {
				preparedStatement.close();
			}
			if(connection != null) {
				connection.close();
			}
		}
		return flag;
	}
	
	
}
