package exam_student;

import java.util.Objects;

public class Member {
	private int memberNo;
	private String memberID;
	private String memberName;
	
	
	private String memberAddress;

	
	
	
	public Member(String memberID, String memberName, String memberAddress) {
		super();
		this.memberID = memberID;
		this.memberName = memberName;
		this.memberAddress = memberAddress;
	}



	public String getMemberID() {
		return memberID;
	}



	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}



	public String getMemberName() {
		return memberName;
	}



	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}



	public String getMemberAddress() {
		return memberAddress;
	}



	public void setMemberAddress(String memberAddress) {
		this.memberAddress = memberAddress;
	}


	@Override
	public String toString() {
		return "Member [memberID=" + memberID + ", memberName=" + memberName + ", memberAddress=" + memberAddress + "]";
	}
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return Objects.hash(memberID);
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Member) {
			Member member = (Member)obj;
			if(this.memberID.equals(member.getMemberID())) {
				return true;
			}
		}
		return false;
	}
	
	
	
}
