package exam_student;

public class ScoreTable {
	
	private int no;
	private String id;
	private String studentName;
	private int java;
	private int dataB;
	private int android;
	private int c;
	private int total;
	private double avg;
	private String grade;
	
	
	
	public ScoreTable(String id, String studentName, int java, int dataB, int android, int c, int total,
			double avg, String grade) {
		super();

		this.id = id;
		this.studentName = studentName;
		this.java = java;
		this.dataB = dataB;
		this.android = android;
		this.c = c;
		this.total = total;
		this.avg = avg;
		this.grade = grade;
	}


	public ScoreTable(String id2, String studentName2, int java2, int dataB2, int android2, int c2) {
		this.id = id2;
		this.studentName = studentName2;
		this.java = java2;
		this.dataB = dataB2;
		this.android = android2;
		this.c = c2;
		
	}


	public ScoreTable(int no, String id, String studentName, int java, int dataB, int android, int c, int total,
			double avg, String grade) {
		super();
		this.no=no;
		this.id = id;
		this.studentName = studentName;
		this.java = java;
		this.dataB = dataB;
		this.android = android;
		this.c = c;
		this.total = total;
		this.avg = avg;
		this.grade = grade;
	}

	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public int getJava() {
		return java;
	}


	public void setJava(int java) {
		this.java = java;
	}

	public int getDataB() {
		return dataB;
	}

	
	public void setDataB(int dataB) {
		this.dataB = dataB;
	}


	public int getAndroid() {
		return android;
	}


	public void setAndroid(int android) {
		this.android = android;
	}

	
	public int getTotal() {
		return total;
	}


	public void setTotal(int total) {
		this.total = total;
	}


	public double getAvg() {
		return avg;
	}


	public void setAvg(double avg) {
		this.avg = avg;
	}


	public String getGrade() {
		return grade;
	}


	public void setGrade(String grade) {
		this.grade = grade;
	}

	@Override
	public String toString() {
		return no + "\t" + id + "\t" + studentName + "\t" + java + "\t"
				+ dataB + "\t" + android + "\t" + c + "\t" + total + "\t" + avg + "\t" + grade;
	}

	
}
