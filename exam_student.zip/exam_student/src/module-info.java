module exam_student {
	requires java.sql;
	requires java.management;
}